# plugin.video.aniverse/resources/lib/gui/app.py
"""AniVerse app window (M12): sidebar + Home, Grid and Related (M14) views, the screen stack and Back.
Everything it shows comes from gui/lists.py; everything it does goes through gui/actions.py."""

import xbmcgui

from resources.lib.gui import actions, dialogs, ids, items, lists
from resources.lib.gui.home import HomeView
from resources.lib.gui.related import RelatedView
from resources.lib.gui.loader import Loader, PlaybackWatch, Ticker, report
from resources.lib.kodi import paths, ui
from resources.lib.metadata import mal
from resources.lib.metadata.catalog import Catalog
from resources.lib.myanimelist import sync
from resources.lib.storage.favourites import Favourites
from resources.lib.storage.history import History

SIDEBAR = [
    (30244, "home", ("home",)),
    (30002, "search", ("grid", "search")),
    (30001, "play_circle", ("grid", "continue")),
    (30003, "format_list_bulleted", ("grid", "mal")),
    (30004, "star", ("grid", "favourites")),
    (30005, "schedule", ("grid", "airing")),
    (30006, "calendar_month", ("grid", "recent")),
    (30007, "trending_up", ("grid", "trending")),
    (30008, "local_fire_department", ("grid", "popular")),
    (30009, "auto_awesome", ("grid", "upcoming")),
    (30010, "grid_view", ("grid", "genres")),
    (30011, "inventory_2", ("grid", "torbox")),
    (30012, "settings", ("settings",)),
]
GRID_MORE_MARGIN = 6  # within one grid row of the end -> load the next page


class AppWindow(xbmcgui.WindowXML):
    app = None

    def onInit(self):
        self.app.on_init()

    def onAction(self, action):
        self.app.on_action(action)

    def onClick(self, control_id):
        self.app.on_click(control_id)


class GridView:
    def __init__(self, app):
        self.app = app
        self.key = None
        self.cards = []
        self.page = 1
        self.more = False
        self.loading = False

    def load(self, key):
        self.key, self.cards, self.page, self.more = key, [], 1, False
        w = self.app.window
        w.getControl(ids.GRID).reset()
        w.setProperty("grid_title", "")
        w.setProperty("grid_empty", "")
        self._fetch(1)

    def _fetch(self, page_no):
        self.loading = True
        self.app.window.setProperty("loading", "true")
        key = self.key
        self.app.loader.start({key: lambda: lists.load(key, page_no)}, self._deliver)

    def _deliver(self, key, page, error):
        if key != self.key:
            return
        self.loading = False
        self.app.window.setProperty("loading", "")
        if error:
            self.app.report(error)
            self.app.back()
            return
        first = not self.cards
        self.cards.extend(page.cards)
        self.more = page.more
        w = self.app.window
        w.setProperty("grid_title", page.title)
        w.getControl(ids.GRID).addItems(items.to_listitems(page.cards))
        if first:
            w.setProperty("grid_empty", "" if page.cards else (page.empty or ui.string(30256)))
            if page.cards:
                w.setFocusId(ids.GRID)

    def maybe_more(self):
        if not self.more or self.loading:
            return
        position = self.app.window.getControl(ids.GRID).getSelectedPosition()
        if position >= len(self.cards) - GRID_MORE_MARGIN:
            self.page += 1
            self._fetch(self.page)

    def selected(self):
        position = self.app.window.getControl(ids.GRID).getSelectedPosition()
        return self.cards[position] if 0 <= position < len(self.cards) else None

    def refresh(self):
        if self.key in ("continue", "favourites"):
            self.load(self.key)


class App:
    def __init__(self, window, loader=None):
        self.window = window
        self.loader = loader or Loader()
        self.stack = []
        self.view = None
        self.home = HomeView(self)
        self.grid = GridView(self)
        self.related = RelatedView(self)
        self.watch = PlaybackWatch()
        self._started = False

    # -- lifecycle ---------------------------------------------------------------

    def on_init(self):
        if self._started:  # Kodi calls onInit again after the show page or fullscreen video
            if self.view == "grid":
                self.window.setFocusId(ids.GRID)
            elif self.view == "related":
                self.related.focus()
            return
        self._started = True
        self._fill_sidebar()
        self.show_home()

    def _fill_sidebar(self):
        from resources.lib.debrid import service
        entries = []
        for string_id, icon, target in SIDEBAR:
            label = ui.string(string_id) % service.label() if string_id == 30011 else ui.string(string_id)
            item = xbmcgui.ListItem(label=label, offscreen=True)
            item.setProperty("icon", f"av-icon-{icon}.png")
            item.setProperty("target", target[1] if target[0] == "grid" else target[0])
            entries.append(item)
        control = self.window.getControl(ids.SIDEBAR)
        control.reset()
        control.addItems(entries)

    def close(self):
        self.loader.cancel()
        self.window.close()

    def tick(self, now=None):
        if self.view == "home":
            self.home.tick(now)
        if self.watch.ended():
            self._refresh()

    # -- navigation ----------------------------------------------------------------

    def _set_view(self, view, current):
        self.loader.cancel()  # results for the screen being left must not land on the new one
        self.view = view
        self.window.setProperty("view", view)
        self.window.setProperty("current", current)

    def show_home(self):
        self.stack.clear()
        self._set_view("home", "home")
        self.window.setFocusId(ids.HERO_PLAY)  # before loading: an offline result moves focus to Retry
        self.home.load()

    def open_grid(self, key):
        self.stack.append(key)
        self._open(key)

    def _open(self, key):
        name, _, arg = key.partition(":")
        if name == "related":
            self._set_view("related", "related")
            self.related.load(arg)
        else:
            self._set_view("grid", name)
            self.grid.load(key)

    def back(self):
        if self.view not in ("grid", "related"):
            self.close()
            return
        if self.stack:
            self.stack.pop()
        if self.stack:
            self._open(self.stack[-1])
        else:
            self.show_home()

    def _refresh(self):
        if self.view == "home":
            self.home.refresh_continue()
        elif self.view == "grid":
            self.grid.refresh()

    # -- input -----------------------------------------------------------------------

    def on_action(self, action):
        action_id = action.getId()
        if action_id in ids.ACTION_BACK:
            self.back()
        elif action_id in ids.ACTION_CONTEXT:
            self._context_menu()
        elif action_id in (ids.ACTION_MOVE_RIGHT, ids.ACTION_MOVE_DOWN) and self.window.getFocusId() == ids.GRID:
            self.grid.maybe_more()

    def on_click(self, control_id):
        if control_id == ids.SIDEBAR:
            position = self.window.getControl(ids.SIDEBAR).getSelectedPosition()
            if 0 <= position < len(SIDEBAR):
                target = SIDEBAR[position][2]
                if target[0] == "grid":
                    self.stack.clear()  # a sidebar choice starts a new trail; Back returns Home
                self.run(target)
        elif control_id in (ids.HERO_PLAY, ids.HERO_INFO) or control_id in ids.HOME_ROWS:
            self.home.on_click(control_id)
        elif control_id in ids.RELATED_ROWS:
            self.related.on_click(control_id)
        elif control_id == ids.HOME_RETRY:
            self.home.load()
        elif control_id == ids.GRID:
            card = self.grid.selected()
            if card:
                self.run(card.action)

    def run(self, action):
        kind = action[0] if action else "noop"
        if kind == "home":
            self.show_home()
        elif kind == "grid":
            self.open_grid(action[1])
        elif kind == "related":
            self.open_grid(f"related:{action[1]}")
        elif kind == "settings":
            actions.open_settings()
        elif kind == "show":
            from resources.lib.gui import show
            result = show.open_show(action[1])
            if result:
                self.run(result)
            else:
                self._refresh()  # favourites or watched marks may have changed
        elif kind == "play":
            actions.play_episode(*action[1:])
        elif kind == "episode":
            actions.episode_choice(*action[1:])
        elif kind == "search_new":
            text = actions.search_keyboard()
            if text:
                self.open_grid(f"search:{text}")
        elif kind == "magnet":
            actions.add_magnet()
            self.grid.load(self.grid.key)
        elif kind == "plugin_play":
            actions.play_url(action[1])

    def report(self, error):
        if isinstance(error, mal.MalSetupMissing):
            if ui.confirm(ui.string(30003), ui.string(30075)):
                ui.open_settings()
        elif isinstance(error, mal.MalUserUnavailable):
            ui.ok(ui.string(30003), ui.string(30076) % ui.setting("mal_username"))
        elif isinstance(error, mal.MalClientRejected):
            if ui.confirm(ui.string(30003), ui.string(30077)):
                ui.open_settings()
        elif isinstance(error, lists.ServiceMissing):
            from resources.lib.views import sources
            sources._setup_service(None)
        else:
            report(error, "AniVerse window")

    def _focused_card(self):
        focus = self.window.getFocusId()
        if focus == ids.GRID:
            return self.grid.selected()
        if focus in ids.HOME_ROWS:
            return self.home.selected(focus)
        if focus in ids.RELATED_ROWS:
            return self.related.selected(focus)
        return None

    def _context_menu(self):
        card = self._focused_card()
        if not card or not card.action or card.action[0] != "show":
            return
        anilist_id = card.action[1]
        favs = Favourites(paths.profile_dir())
        try:
            favourite = anilist_id in favs.ids()
        finally:
            favs.close()
        choice = dialogs.menu(card.label, [ui.string(30061 if favourite else 30060), ui.string(30223),
                                           ui.string(30224), ui.string(30034)])
        if choice == 0:
            favs = Favourites(paths.profile_dir())
            try:
                if favourite:
                    favs.remove(anilist_id)
                    ui.notify("AniVerse", ui.string(30064))
                else:
                    show = Catalog().show(anilist_id)
                    favs.add(show)
                    ui.notify(show.title, ui.string(30063))
            finally:
                favs.close()
        elif choice == 1:
            catalog = Catalog()
            show = catalog.show(anilist_id)
            numbers = [e.number for e in catalog.episodes(show)]
            History(paths.profile_dir()).mark_show(anilist_id, numbers, True)
            sync.queue_show(paths.profile_dir(), anilist_id, "show_watched", max(numbers, default=0),
                            mal_id=show.mal_id)
        elif choice == 2:
            if ui.confirm("AniVerse", ui.string(30227)):
                History(paths.profile_dir()).mark_show(anilist_id, [], False)
                sync.queue_show(paths.profile_dir(), anilist_id, "show_unwatched")
        elif choice == 3:
            self.run(("related", anilist_id))
            return
        self._refresh()


def run():
    window = AppWindow("aniverse-app.xml", ui.addon().getAddonInfo("path"), "Default", "1080i")
    app = App(window)
    window.app = app
    ticker = Ticker(app.tick)
    ticker.start()
    try:
        window.doModal()
    finally:
        ticker.stop()
        app.loader.cancel()
