# plugin.video.aniverse/resources/lib/gui/actions.py
"""What selecting a card does (M12). Playback always goes through the existing play route."""

import xbmc

from resources.lib import router
from resources.lib.gui import cards, dialogs
from resources.lib.kodi import paths, ui
from resources.lib.metadata.catalog import Catalog
from resources.lib.storage.history import History


def play_url(url):
    xbmc.executebuiltin(f"PlayMedia({url})")


def play_episode(anilist_id, episode, resume_s=0):
    play_url(router.build_url("play", id=anilist_id, ep=episode, resume=int(resume_s) if resume_s else None))


def search_episode(anilist_id, episode):
    """Search the providers again (ignoring saved results), then the usual source list."""
    play_url(router.build_url("play", id=anilist_id, ep=episode, refresh=1))


def play_next(show):
    from resources.lib.myanimelist import progress
    numbers = [e.number for e in Catalog().episodes(show)]
    states = progress.merge_states(History(paths.profile_dir()).states(show.anilist_id),
                                   progress.show_entry(show.mal_id, network=False))  # GUI thread: never wait on MAL
    episode, resume_s = cards.next_episode(numbers, states)
    play_episode(show.anilist_id, episode, resume_s)


def episode_choice(anilist_id, episode):
    """Started, unwatched episode: ask Resume / From start (spec §6); otherwise play."""
    state = History(paths.profile_dir()).states(anilist_id).get(episode)
    if state and state[0] > 0 and not state[2]:
        choice = dialogs.resume_choice(state[0])
        if choice is None:
            return
        play_episode(anilist_id, episode, state[0] if choice else 0)
        return
    play_episode(anilist_id, episode)


def take_open_show():
    """End episode (playback/monitor.py): the show page to return to, read once; None if none."""
    from resources.lib.playback.monitor import OPEN_SHOW_PROPERTY
    value = ui.get_window_property(OPEN_SHOW_PROPERTY)
    if not value:
        return None
    ui.clear_window_property(OPEN_SHOW_PROPERTY)
    try:
        return int(value)
    except ValueError:
        return None


def search_keyboard():
    return ui.keyboard(ui.string(30032))


def add_magnet():
    from resources.lib.views import sources
    sources.add_magnet(router.Request(handle=-1, path="rd/add_magnet"))


def open_settings():
    ui.open_settings()
