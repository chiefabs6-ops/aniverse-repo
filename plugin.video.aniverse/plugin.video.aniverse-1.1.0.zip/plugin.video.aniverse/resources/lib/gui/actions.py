# plugin.video.aniverse/resources/lib/gui/actions.py
"""What selecting a card does (M12). Playback always goes through the existing play route."""

import xbmc

from resources.lib import router
from resources.lib.gui import cards, dialogs
from resources.lib.kodi import paths, ui
from resources.lib.metadata.catalog import Catalog
from resources.lib.storage.history import History


def play_url(url):
    xbmc.executebuiltin(f"PlayMedia({url})")


def play_episode(anilist_id, episode, resume_s=0):
    play_url(router.build_url("play", id=anilist_id, ep=episode, resume=int(resume_s) if resume_s else None))


def play_next(show):
    numbers = [e.number for e in Catalog().episodes(show)]
    episode, resume_s = cards.next_episode(numbers, History(paths.profile_dir()).states(show.anilist_id))
    play_episode(show.anilist_id, episode, resume_s)


def episode_choice(anilist_id, episode):
    """Started, unwatched episode: ask Resume / From start (spec §6); otherwise play."""
    state = History(paths.profile_dir()).states(anilist_id).get(episode)
    if state and state[0] > 0 and not state[2]:
        choice = dialogs.resume_choice(state[0])
        if choice is None:
            return
        play_episode(anilist_id, episode, state[0] if choice else 0)
        return
    play_episode(anilist_id, episode)


def search_keyboard():
    return ui.keyboard(ui.string(30032))


def add_magnet():
    from resources.lib.views import sources
    sources.add_magnet(router.Request(handle=-1, path="rd/add_magnet"))


def open_settings():
    ui.open_settings()
