# plugin.video.aniverse/resources/lib/gui/ids.py
"""Control IDs shared by the Python controllers and the XML layouts (M12).
tests/test_layouts.py checks every ID listed in WINDOW_IDS exists in its layout."""

SIDEBAR = 100
HERO_PLAY = 201
HERO_INFO = 202
HOME_ROWS = (300, 310, 320, 330)
HOME_RETRY = 340
GRID = 400
SHOW_PLAY = 500
SHOW_FAVOURITE = 501
SHOW_RELATED = 502
SHOW_EPISODES = 510
SOURCES_LIST = 600
CONFIRM_YES = 700
CONFIRM_NO = 701
PROGRESS_BAR = 710
PROGRESS_CANCEL = 711
MENU_LIST = 720
PROMPT_BUTTON = 9000

ACTION_BACK = {9, 10, 92}        # parent dir, previous menu, back
ACTION_CONTEXT = {117}           # context menu / hold OK
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_DOWN = 4

# Each task that adds a layout adds its entry here.
WINDOW_IDS = {
    "aniverse-prompt.xml": [PROMPT_BUTTON],
    "aniverse-login.xml": [9000],
    "aniverse-confirm.xml": [CONFIRM_YES, CONFIRM_NO],
    "aniverse-progress.xml": [PROGRESS_BAR, PROGRESS_CANCEL],
    "aniverse-sources.xml": [SOURCES_LIST],
    "aniverse-menu.xml": [MENU_LIST],
    "aniverse-show.xml": [SHOW_PLAY, SHOW_FAVOURITE, SHOW_RELATED, SHOW_EPISODES],
    "aniverse-app.xml": [SIDEBAR, HERO_PLAY, HERO_INFO, *HOME_ROWS, HOME_RETRY, GRID],
}
